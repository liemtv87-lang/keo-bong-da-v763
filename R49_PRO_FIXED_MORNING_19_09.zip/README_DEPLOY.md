# R49 PRO — Cloudflare

Worker name: `keobongda-pro`

This repository is prepared for Cloudflare Workers + Static Assets + Durable Objects.
Secrets must stay server-side:
- `PINNWIRE_KEY`
- `RAPIDODDS_KEY`

After deployment check:
- `/api/health`
- `/api/background/state`
- `/api/background/key/providers`

The app also has `/setup-keys` to bootstrap the two server keys into the private Durable Object without exposing them in frontend code.
