const VN_OFFSET=7*3600_000;
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&amp;/g,'and').replace(/[^a-z0-9]+/g,' ').trim();
const BIG_TEAMS=[
 'real madrid','barcelona','atletico madrid','athletic bilbao','sevilla','villarreal','real sociedad',
 'manchester city','manchester united','liverpool','arsenal','chelsea','tottenham','newcastle united','aston villa',
 'bayern munich','borussia dortmund','rb leipzig','bayer leverkusen','eintracht frankfurt',
 'inter milan','internazionale','ac milan','juventus','napoli','roma','lazio','atalanta',
 'paris saint germain','psg','marseille','monaco','lyon','lille',
 'benfica','porto','sporting cp','sporting lisbon','ajax','psv','feyenoord',
 'galatasaray','fenerbahce','besiktas','olympiacos','celtic','rangers',
 'river plate','boca juniors','flamengo','palmeiras','corinthians','sao paulo','fluminense','botafogo','gremio','internacional',
 'al hilal','al nassr','al ittihad','al ahli','inter miami','la galaxy',
 'argentina','brazil','brasil','france','spain','england','germany','italy','portugal','netherlands','belgium','croatia','uruguay','colombia','japan','south korea'
].map(norm);
function isMinorFixture(p){const x=norm(`${p?.league||''} ${p?.home||''} ${p?.away||''}`);return /(^| )(u1[6789]|u2[013]|u23|youth|reserve|reserves|women|womens|femen|femin|academy|amateur|friendly)( |$)/.test(x)}
function teamTier(name){const x=norm(name);if(!x)return 0;for(const t of BIG_TEAMS)if(x===t||(x.length>=5&&t.length>=5&&(x.includes(t)||t.includes(x))))return 1;return 0}
export function leagueRank(name){const x=norm(name);const rules=[
 [100,/champions league|uefa champions|ucl/],[99,/world cup|fifa world|euro 20|uefa euro|copa america/],
 [96,/premier league|england.*premier|epl/],[94,/la liga|primera division.*spain|spain.*primera/],
 [92,/serie a.*ital|ital.*serie a/],[90,/bundesliga/],[88,/ligue 1|france.*ligue 1/],
 [86,/europa league|uefa europa/],[84,/conference league|uefa conference/],[83,/copa libertadores|libertadores/],
 [82,/club world cup|fifa club/],[80,/brasileir|brazil.*serie a|argentina.*primera|liga profesional/],
 [78,/afc champions|champions league elite|saudi pro|primeira liga|eredivisie|super lig|major league soccer|mls/],
 [75,/fa cup|copa del rey|coppa italia|dfb pokal|coupe de france|efl cup|carabao/],
 [72,/nations league|world cup qualification|euro qualification|qualif/]
 ];for(const [s,re] of rules)if(re.test(x))return s;return 40}
export function nextThreeAmVN(from=Date.now()){
 const v=new Date(from+VN_OFFSET);const y=v.getUTCFullYear(),m=v.getUTCMonth(),d=v.getUTCDate();return Date.UTC(y,m,d+1,3,0,0)-VN_OFFSET;
}
export function bigMatchMeta(p){const rank=leagueRank(p?.league),home=teamTier(p?.home),away=teamTier(p?.away),both=home+away>=2,one=home+away>=1,books=Math.min(Number(p?.ah?.books||0),Number(p?.ou?.books||0)),balance=(Number(p?.ah?.mainBalance||.08)+Number(p?.ou?.mainBalance||.08))/2,method=(Number(p?.ah?.methodConsensus||.5)+Number(p?.ou?.methodConsensus||.5))/2,strength=(Number(p?.ah?.strength||0)+Number(p?.ou?.strength||0))/2,quality=Math.max(0,books*3+(1-Math.min(.2,balance)*5)*8+method*5+strength*4),hot=both||(rank>=96&&one)||(rank>=99);return{leagueRank:rank,hot,quality:+quality.toFixed(3),bigTeams:home+away}}
export function rankBigPredictions(rows,from=Date.now(),to=nextThreeAmVN(from),limit=30){
 const seen=new Set(),pool=[];for(const p of rows||[]){const t=Date.parse(p?.date);if(!Number.isFinite(t)||t<from||t>to)continue;const k=`${norm(p.home)}|${norm(p.away)}|${Math.round(t/60000)}`;if(seen.has(k))continue;seen.add(k);pool.push({...p,bigMatch:bigMatchMeta(p)})}
 const eligible=pool.filter(p=>!isMinorFixture(p)&&(p.bigMatch.hot||p.bigMatch.leagueRank>=72||p.bigMatch.bigTeams>0));
 eligible.sort((a,b)=>Number(b.bigMatch.hot)-Number(a.bigMatch.hot)||b.bigMatch.leagueRank-a.bigMatch.leagueRank||b.bigMatch.bigTeams-a.bigMatch.bigTeams||b.bigMatch.quality-a.bigMatch.quality||Date.parse(a.date)-Date.parse(b.date));
 const chosen=eligible.slice(0,Math.max(1,Math.min(30,limit)));
 // Requirement: choose the biggest fixtures first, then display those chosen fixtures chronologically.
 return chosen.sort((a,b)=>Date.parse(a.date)-Date.parse(b.date));
}
