import {cleanLabel} from './text-codec.mjs';
import {leagueRank,bigMatchMeta} from './public/big-matches.mjs';

const norm=s=>cleanLabel(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\(n\)/g,'').replace(/\b(fc|cf|sc|afc|club|the)\b/g,'').replace(/[^\p{L}\p{N}]/gu,'');
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,Number(x)||0));
const avg=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
const weighted=(rows,key)=>{let n=0,d=0;for(const x of rows){const v=Number(x[key]);if(!Number.isFinite(v))continue;const w=Number(x.w)||1;n+=v*w;d+=w}return d?n/d:null};

function scorePair(e){
 const h=e?.homeScore?.normaltime??e?.homeScore?.current,a=e?.awayScore?.normaltime??e?.awayScore?.current;
 return Number.isFinite(h)&&Number.isFinite(a)?[Number(h),Number(a)]:null;
}
function finishedEvents(events,before){return (events||[]).filter(e=>Number(e?.startTimestamp)*1000<before&&e?.status?.type==='finished'&&scorePair(e)).sort((a,b)=>Number(b.startTimestamp)-Number(a.startTimestamp));}
function restDays(events,before){const e=finishedEvents(events,before)[0];return e?Math.max(0,(before-Number(e.startTimestamp)*1000)/86400000):null}

function expected(home,away){return 1/(1+10**((away-home)/400));}
export function rollingElo(homeId,awayId,homeEvents,awayEvents,before){
 const map=new Map(),games=new Map();
 for(const e of [...finishedEvents(homeEvents,before),...finishedEvents(awayEvents,before)]) if(!games.has(String(e.id)))games.set(String(e.id),e);
 const rows=[...games.values()].sort((a,b)=>Number(a.startTimestamp)-Number(b.startTimestamp));
 const rating=id=>map.get(String(id))??1500;
 for(const e of rows){const hid=e.homeTeam?.id,aid=e.awayTeam?.id,s=scorePair(e);if(hid==null||aid==null||!s)continue;const rh=rating(hid),ra=rating(aid),ex=expected(rh+45,ra),act=s[0]===s[1]?.5:s[0]>s[1]?1:0,k=20,delta=k*(act-ex);map.set(String(hid),rh+delta);map.set(String(aid),ra-delta)}
 const h=rating(homeId),a=rating(awayId),oppRatings=(events,id)=>finishedEvents(events,before).slice(0,10).map(e=>{const isHome=String(e.homeTeam?.id)===String(id),opp=isHome?e.awayTeam?.id:e.homeTeam?.id;return rating(opp)}).filter(Number.isFinite);
 return{home:+h.toFixed(1),away:+a.toFixed(1),diff:+(h-a).toFixed(1),homeSOS:+(avg(oppRatings(homeEvents,homeId))??1500).toFixed(1),awaySOS:+(avg(oppRatings(awayEvents,awayId))??1500).toFixed(1),games:rows.length};
}

export function parseXgStats(j){
 const periods=Array.isArray(j?.statistics)?j.statistics:[];const all=periods.find(x=>String(x.period||'').toUpperCase()==='ALL')||periods[0];
 if(!all)return null;let h=null,a=null;
 for(const g of all.groups||[])for(const it of g.statisticsItems||[]){const n=String(it.name||'').toLowerCase().replace(/[^a-z]/g,'');if(n==='expectedgoals'||n==='xg'){const hv=Number(String(it.home??'').replace(',','.')),av=Number(String(it.away??'').replace(',','.'));if(Number.isFinite(hv)&&Number.isFinite(av)){h=hv;a=av}}}
 return Number.isFinite(h)&&Number.isFinite(a)?{home:h,away:a}:null;
}
async function xgSummary(events,teamId,before,getJson,max=5){
 const rows=[];for(const e of finishedEvents(events,before).slice(0,max)){try{const j=await getJson(`/event/${e.id}/statistics`),x=parseXgStats(j);if(!x)continue;const home=String(e.homeTeam?.id)===String(teamId),days=Math.max(0,(before-Number(e.startTimestamp)*1000)/86400000),w=Math.exp(-days/75);rows.push({xgf:home?x.home:x.away,xga:home?x.away:x.home,w})}catch{}}
 return{n:rows.length,xgf:weighted(rows,'xgf'),xga:weighted(rows,'xga')};
}
function goalsSummary(events,teamId,before,venue){const rows=[];for(const e of finishedEvents(events,before).slice(0,12)){const s=scorePair(e),home=String(e.homeTeam?.id)===String(teamId);if(!s||(venue&&venue!==(home?'home':'away')))continue;const days=(before-Number(e.startTimestamp)*1000)/86400000,w=Math.exp(-days/70);rows.push({gf:home?s[0]:s[1],ga:home?s[1]:s[0],w})}return{n:rows.length,gf:weighted(rows,'gf'),ga:weighted(rows,'ga')};}
function leagueGoalContext(eventsA,eventsB,tournamentId,before){const seen=new Set(),rows=[];for(const e of [...finishedEvents(eventsA,before),...finishedEvents(eventsB,before)]){if(seen.has(String(e.id)))continue;seen.add(String(e.id));const tid=e?.tournament?.id??e?.uniqueTournament?.id??e?.tournament?.uniqueTournament?.id;if(tournamentId!=null&&tid!=null&&String(tid)!==String(tournamentId))continue;const s=scorePair(e);if(!s)continue;const days=(before-Number(e.startTimestamp)*1000)/86400000,w=Math.exp(-days/120);rows.push({total:s[0]+s[1],w})}return{n:rows.length,mean:weighted(rows,'total')};}

function pmf(lambda){const a=[Math.exp(-lambda)];for(let i=1;i<=16;i++)a.push(a[i-1]*lambda/i);return a}
function asianGrade(score,line){const split=Math.abs(line*2-Math.round(line*2))>1e-8?[Math.floor(line*2)/2,Math.ceil(line*2)/2]:[line];return split.reduce((s,l)=>s+Math.sign(score+l),0)/split.length}
function expectation(lh,la,type,line){const hp=pmf(Math.max(.15,Math.min(7,lh))),ap=pmf(Math.max(.15,Math.min(7,la)));let left=0,right=0,mass=0;for(let i=0;i<hp.length;i++)for(let j=0;j<ap.length;j++){const q=hp[i]*ap[j];mass+=q;if(type==='AH'){const g=asianGrade(i-j,line);left+=q*g;right-=q*g}else{const g=asianGrade(i+j,-line);left+=q*g;right-=q*g}}return{left:left/Math.max(mass,1e-9),right:right/Math.max(mass,1e-9)}}
function probFromEG(eg){return clamp(.5+Math.sign(eg)*Math.min(.43,Math.abs(eg)*.31),.05,.95)}
function xgModel(p,form){
 if(!form?.homeXg?.n||!form?.awayXg?.n)return null;
 const hg=form.homeGoals,ag=form.awayGoals,hx=form.homeXg,ax=form.awayXg;
 const hxgf=Number(hx.xgf),hxga=Number(hx.xga),axgf=Number(ax.xgf),axga=Number(ax.xga);if(![hxgf,hxga,axgf,axga].every(Number.isFinite))return null;
 // xG is the base; finishing is regressed strongly toward 1.00 so a short hot/cold streak cannot dominate.
 const hFinish=clamp(Number(hg.gf||0)/Math.max(.35,hxgf),.65,1.35),aFinish=clamp(Number(ag.gf||0)/Math.max(.35,axgf),.65,1.35);
 const hReg=.82+.18*hFinish,aReg=.82+.18*aFinish;
 let lh=((hxgf+axga)/2)*hReg,la=((axgf+hxga)/2)*aReg;
 // Tournament-specific scoring environment, shrunk to neutral 2.70 unless there are enough same-league samples.
 const lc=form.leagueGoals||{},leagueMean=Number(lc.mean),leagueW=clamp((Number(lc.n)||0)/18,0,.65);if(Number.isFinite(leagueMean)&&leagueMean>1){const target=2.70*(1-leagueW)+leagueMean*leagueW,scale=clamp(target/Math.max(.5,lh+la),.86,1.14);lh*=scale;la*=scale}
 const eloAdj=clamp((form.elo.diff||0)/650,-.24,.24),sosAdj=clamp(((form.elo.homeSOS||1500)-(form.elo.awaySOS||1500))/900,-.08,.08),restAdj=clamp(((form.awayRest??5)-(form.homeRest??5))/16,-.05,.05);lh*=1+eloAdj*.22+sosAdj-restAdj;la*=1-eloAdj*.22-sosAdj+restAdj;
 // Enumerating two Poisson score distributions is equivalent to using the Skellam goal-difference distribution for AH.
 const ah=expectation(lh,la,'AH',p.ah.line),ou=expectation(lh,la,'OU',p.ou.line);return{homeGoals:+lh.toFixed(3),awayGoals:+la.toFixed(3),finishingRegression:{home:+hReg.toFixed(3),away:+aReg.toFixed(3)},leagueCalibration:{n:Number(lc.n)||0,mean:Number.isFinite(leagueMean)?+leagueMean.toFixed(3):null},AH:{pick:ah.left>=0?'Home':'Away',prob:+probFromEG(ah.left).toFixed(4),expectedGrade:+ah.left.toFixed(4)},OU:{pick:ou.left>=0?'Over':'Under',prob:+probFromEG(ou.left).toFixed(4),expectedGrade:+ou.left.toFixed(4)}};
}
function eloVote(p,elo){const edge=(Number(elo.diff)||0)/400-(Number(p.line)||0)*.65,prob=clamp(.5+Math.tanh(edge)*.19,.15,.85);return{pick:prob>=.5?'Home':'Away',prob:+prob.toFixed(4)}}

export function parseTipText(html){return String(html||'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/\s+/g,' ').trim()}
function scoreNearTeams(p,html){if(!html)return null;const text=parseTipText(html),lower=text.toLowerCase(),h=cleanLabel(p.home).toLowerCase(),a=cleanLabel(p.away).toLowerCase(),hi=lower.indexOf(h);if(hi<0)return null;const seg=text.slice(hi,hi+Math.max(420,h.length+a.length+300)),sl=seg.toLowerCase(),ai=sl.indexOf(a);if(ai<0)return null;const tail=seg.slice(ai+a.length,ai+a.length+220);let m=tail.match(/(?:home|away|draw|prediction|pred|tip|x|1|2)?\s*(\d{1,2})\s*[-:]\s*(\d{1,2})\b/i);if(!m){const pre=seg.slice(Math.max(0,ai-120),ai);m=pre.match(/(\d{1,2})\s*[-:]\s*(\d{1,2})\s*$/)}if(!m)return null;const hs=Number(m[1]),as=Number(m[2]);return hs<=12&&as<=12?[hs,as]:null}
function sourceVote(p,source,html){const s=scoreNearTeams(p,html);if(!s)return null;const [hs,as]=s,ahg=asianGrade(hs-as,p.ah.line),oug=asianGrade(hs+as,-p.ou.line);return{source,score:`${hs}-${as}`,AH:{pick:ahg>=0?'Home':'Away'},OU:{pick:oug>=0?'Over':'Under'}}}
export function forebetVote(p,html){return sourceVote(p,'Forebet',html)}
export function expertConsensusVote(p,pages={},weights={}){const defs=[['Forebet',pages.forebet],['PredictZ',pages.predictz],['WinDrawWin',pages.windrawwin]],raw=[];for(const [name,html] of defs){const w=clamp(weights?.[name]??.65,0,1.25);if(w<.12)continue;const v=sourceVote(p,name,html);if(v)raw.push({...v,weight:w})}if(!raw.length)return null;
 // Exact score/pick duplicates are treated as one opinion cluster so copied tip pages cannot manufacture consensus.
 const groups=new Map();for(const v of raw){const k=`${v.score}|${v.AH.pick}|${v.OU.pick}`,a=groups.get(k)||[];a.push(v);groups.set(k,a)}const votes=[];for(const a of groups.values()){const cap=Math.min(1.05,Math.max(...a.map(x=>x.weight)));const sum=a.reduce((s,x)=>s+x.weight,0)||1;for(const v of a)votes.push({...v,weight:cap*v.weight/sum,duplicateGroupSize:a.length})}
 const calc=type=>{const left=type==='AH'?'Home':'Over';let L=0,R=0;for(const v of votes)(v[type].pick===left?L+=v.weight:R+=v.weight);const total=Math.max(.001,L+R),pick=L>=R?left:(type==='AH'?'Away':'Under'),agree=Math.max(L,R)/total,independentGroups=groups.size,confidence=clamp(.51+.17*agree+.025*Math.min(3,independentGroups),.53,.76);return{pick,confidence:+confidence.toFixed(4),agreement:+agree.toFixed(4),n:raw.length,independentGroups}};return{sources:votes,rawSourceCount:raw.length,independentGroups:groups.size,AH:calc('AH'),OU:calc('OU')};}

function lineupInfo(j,missing){const list=x=>(x?.missingPlayers||x?.players||[]),missHome=list(missing?.home||missing?.homeTeam||{}),missAway=list(missing?.away||missing?.awayTeam||{}),conf=j?.confirmed===true||j?.confirmedLineups===true;return{available:!!(j?.home||j?.away),confirmed:conf,homeMissing:missHome.length,awayMissing:missAway.length,homePlayers:(j?.home?.players||[]).length,awayPlayers:(j?.away?.players||[]).length}}

export function movementVote(type,p,movement){if(movement===undefined){movement=p;p=null}if(!movement?.first||!movement?.last)return null;const f=movement.first,l=movement.last,dl=Number(l.line)-Number(f.line),left=type==='AH'?'Home':'Over',right=type==='AH'?'Away':'Under';let score=0;if(type==='AH')score+=-dl*.9;else score+=dl*.75;const fp=Number(f.leftOdd),lp=Number(l.leftOdd),fr=Number(f.rightOdd),lr=Number(l.rightOdd);if([fp,lp].every(Number.isFinite))score+=(fp-lp)*.45;if([fr,lr].every(Number.isFinite))score-=(fr-lr)*.45;const checkpoints=['h6','h3','h1','m15'].map(k=>movement?.[k]).filter(Boolean);for(let i=1;i<checkpoints.length;i++){const a=checkpoints[i-1],b=checkpoints[i],step=Number(b.line)-Number(a.line);if(Number.isFinite(step))score+=(type==='AH'?-step:step)*.12}const prob=clamp(.5+Math.tanh(score)*.20,.2,.8);return{pick:prob>=.5?left:right,prob:+prob.toFixed(4),lineMove:+dl.toFixed(3),points:Number(movement.points||0)}}

export function proGate(p,pro,{big=false}={}){
 const out={...p};for(const type of ['AH','OU']){const slot=type==='AH'?'ah':'ou',z={...p[slot]},left=type==='AH'?'Home':'Over';const sig=[];
  sig.push({id:'market',pick:z.pick,w:1.0,prob:.5+Math.min(.18,Number(z.strength||0)*.18)});
  if(pro?.xgModel?.[type])sig.push({id:'xg',pick:pro.xgModel[type].pick,w:1.20,prob:pro.xgModel[type].prob});
  if(type==='AH'&&pro?.eloVote)sig.push({id:'elo',pick:pro.eloVote.pick,w:.78,prob:pro.eloVote.prob});
  if(pro?.movement?.[type])sig.push({id:'movement',pick:pro.movement[type].pick,w:.92,prob:pro.movement[type].prob});
  if(pro?.expert?.[type])sig.push({id:'expert',pick:pro.expert[type].pick,w:.62,prob:pro.expert[type].confidence||.56});
  let L=0,R=0;for(const s of sig){const w=s.w*Math.max(.3,Math.abs((s.prob||.5)-.5)*2+.35);(s.pick===left?L+=w:R+=w)}const consensus=Math.max(L,R)/Math.max(.0001,L+R),independent=sig.filter(s=>s.id!=='market').length,books=Number(z.books||0),dq=Number(pro?.dataQuality||0),lineupPenalty=(pro?.lineup?.available?Math.min(.08,(pro.lineup.homeMissing+pro.lineup.awayMissing)*.008):.025),confidence=clamp(.30*consensus+.20*Math.min(1,books/5)+.28*dq+.22*Math.min(1,independent/3)-lineupPenalty);
  const needIndependent=big?1:2,threshold=big ? .57 : .64,minBooks=big?2:3,actionable=books>=minBooks&&independent>=needIndependent&&dq>=(big ? .36 : .5)&&confidence>=threshold;
  z.proConsensus=+consensus.toFixed(4);z.proConfidence=+confidence.toFixed(4);z.independentSignals=independent;z.actionable=actionable;z.noBetReason=actionable?'':books<minBooks?`Thiếu độ phủ main-line (${books}/${minBooks} book)`:independent<needIndependent?`Thiếu tín hiệu độc lập (${independent}/${needIndependent})`:dq<(big ? .36 : .5)?'Dữ liệu đội bóng chưa đủ sâu':`Edge chưa đạt ngưỡng (${(confidence*100).toFixed(0)}% < ${(threshold*100).toFixed(0)}%)`;
  z.methodVotes={...(z.methodVotes||{})};z.methodProbabilities={...(z.methodProbabilities||{})};if(pro?.xgModel?.[type]){z.methodVotes.xg_poisson=pro.xgModel[type].pick;z.methodProbabilities.xg_poisson=pro.xgModel[type].prob}if(type==='AH'&&pro?.eloVote){z.methodVotes.elo_sos=pro.eloVote.pick;z.methodProbabilities.elo_sos=pro.eloVote.prob}if(pro?.movement?.[type]){z.methodVotes.line_movement=pro.movement[type].pick;z.methodProbabilities.line_movement=pro.movement[type].prob}if(pro?.expert?.[type]){z.methodVotes.expert_consensus=pro.expert[type].pick;z.methodProbabilities.expert_consensus=pro.expert[type].confidence||.56}
  out[slot]=z}
 return out;
}

export async function enrichProPrediction(p,getJson,{expertPages={},expertWeights={},movement=null}={}){
 const before=Date.parse(p.date);try{const day=new Date(before).toISOString().slice(0,10),board=await getJson(`/sport/football/scheduled-events/${day}`),matches=(board.events||[]).filter(e=>Math.abs(Number(e.startTimestamp)*1000-before)<=15*60000&&norm(e.homeTeam?.name)===norm(p.home)&&norm(e.awayTeam?.name)===norm(p.away));if(matches.length!==1)throw Error('Không ghép được đúng SofaScore event');const e=matches[0],[hj,aj,lineup,missing]=await Promise.all([getJson(`/team/${e.homeTeam.id}/events/last/0`),getJson(`/team/${e.awayTeam.id}/events/last/0`),getJson(`/event/${e.id}/lineups`).catch(()=>null),getJson(`/event/${e.id}/missing-players`).catch(()=>null)]),homeGoals=goalsSummary(hj.events,e.homeTeam.id,before,'home'),awayGoals=goalsSummary(aj.events,e.awayTeam.id,before,'away'),elo=rollingElo(e.homeTeam.id,e.awayTeam.id,hj.events,aj.events,before),[homeXg,awayXg]=await Promise.all([xgSummary(hj.events,e.homeTeam.id,before,getJson,5),xgSummary(aj.events,e.awayTeam.id,before,getJson,5)]),line=lineupInfo(lineup,missing),leagueGoals=leagueGoalContext(hj.events,aj.events,e?.tournament?.id??e?.tournament?.uniqueTournament?.id,before),form={homeGoals,awayGoals,homeXg,awayXg,elo,lineup:line,leagueGoals,homeRest:restDays(hj.events,before),awayRest:restDays(aj.events,before)},xg=xgModel(p,form),ev=eloVote(p.ah,elo),expert=expertConsensusVote(p,expertPages,expertWeights),mov={AH:movementVote('AH',p.ah,movement?.AH),OU:movementVote('OU',p.ou,movement?.OU)},coverage=[homeGoals.n>=3,awayGoals.n>=3,elo.games>=6,homeXg.n>=2,awayXg.n>=2,line.available,Number.isFinite(form.homeRest)&&Number.isFinite(form.awayRest),leagueGoals.n>=4,!!expert,!!mov.AH||!!mov.OU].filter(Boolean).length,dataQuality=clamp(coverage/10),pro={status:'available',capturedAt:Date.now(),eventId:e.id,source:'SofaScore xG/xGA + Elo/SOS + lineup/missing + league calibration + market timeline + deduped tip consensus',homeGoals,awayGoals,homeXg,awayXg,elo,lineup:line,leagueGoals,homeRest:form.homeRest,awayRest:form.awayRest,xgModel:xg,eloVote:ev,expert,movement:mov,dataQuality:+dataQuality.toFixed(4)};const big=bigMatchMeta(p).leagueRank>=78||bigMatchMeta(p).hot;return proGate({...p,pro},pro,{big})}catch(err){const expert=expertConsensusVote(p,expertPages,expertWeights),mov={AH:movementVote('AH',p.ah,movement?.AH),OU:movementVote('OU',p.ou,movement?.OU)},pro={status:'partial',capturedAt:Date.now(),reason:cleanLabel(err?.message||err),movement:mov,expert,dataQuality:(expert||mov.AH||mov.OU) ? .32 : .20};return proGate({...p,pro},pro,{big:leagueRank(p.league)>=78})}
}

export function clvFor(type,pick,slot,timeline){if(timeline===undefined){timeline=slot;slot=null}if(!timeline?.first||!timeline?.last)return null;const f=timeline.first,l=timeline.last;let v=0;if(type==='AH'){const sign=pick==='Home'?1:-1;v+=sign*(Number(f.line)-Number(l.line))*0.7}else{const sign=pick==='Over'?1:-1;v+=sign*(Number(l.line)-Number(f.line))*0.6}const isLeft=pick===(type==='AH'?'Home':'Over'),fo=Number(isLeft?f.leftOdd:f.rightOdd),lo=Number(isLeft?l.leftOdd:l.rightOdd);if(fo>1&&lo>1)v+=Math.log(fo/lo)*.6;return +Math.max(-1,Math.min(1,v)).toFixed(4)}
