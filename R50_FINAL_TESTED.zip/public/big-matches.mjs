const VN_OFFSET=7*3600_000;
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&amp;/g,'and').replace(/[^a-z0-9]+/g,' ').trim();
const YOUTH_RE=/(?:^| )(u ?(?:17|18|19|20|21|23)|youth|academy|reserve|reserves|development|premier league 2)(?: |$)/;
const WOMEN_RE=/(?:^| )(women|woman|ladies|female|feminine|femenina|wsl)(?: |$)/;
const FRIENDLY_RE=/(friendly|club friendly|pre season|preseason)/;
const QUAL_RE=/(qualif|qualification|qualifying|preliminary)/;

// Club stature is a secondary signal only. Competition identity always dominates the ranking.
// 3 = globally elite / perennial continental draw, 2 = major-club draw, 1 = notable club/national team.
const TEAM_TIER_3=[
 'real madrid','barcelona','manchester city','manchester united','liverpool','arsenal','chelsea','bayern munich','borussia dortmund',
 'inter milan','internazionale','ac milan','juventus','paris saint germain','psg','atletico madrid'
].map(norm);
const TEAM_TIER_2=[
 'tottenham','newcastle united','aston villa','bayer leverkusen','rb leipzig','napoli','roma','lazio','atalanta','marseille','monaco','lyon',
 'benfica','porto','sporting cp','sporting lisbon','ajax','psv','feyenoord','galatasaray','fenerbahce','besiktas','celtic','rangers',
 'river plate','boca juniors','flamengo','palmeiras','corinthians','sao paulo','fluminense','botafogo','gremio','internacional',
 'al hilal','al nassr','al ittihad','al ahli','inter miami'
].map(norm);
const NATIONAL_TIER_2=['argentina','brazil','brasil','france','spain','england','germany','italy','portugal','netherlands','belgium','croatia','uruguay','colombia','japan','south korea','morocco'].map(norm);
function containsAny(x,list){return list.some(t=>x===t||x.includes(t)||t.includes(x))}
export function teamTier(name){
 const x=norm(name);if(!x||YOUTH_RE.test(x))return 0;
 let t=containsAny(x,TEAM_TIER_3)?3:containsAny(x,TEAM_TIER_2)||containsAny(x,NATIONAL_TIER_2)?2:0;
 if(t&&WOMEN_RE.test(x))t=Math.max(1,t-1);
 return t;
}
function bare(x,...names){return names.includes(x)}
export function leagueRank(name){
 const x=norm(name);if(!x)return 35;
 const youth=YOUTH_RE.test(x),women=WOMEN_RE.test(x),friendly=FRIENDLY_RE.test(x),qual=QUAL_RE.test(x);
 let rank=38;
 // Global / continental senior competitions. Require governing-body/canonical identity.
 if(/uefa champions league/.test(x)&&!qual)rank=100;
 else if(/fifa world cup/.test(x)&&!qual)rank=100;
 else if(/uefa euro(?: |$)/.test(x)&&!qual)rank=99;
 else if(/copa america/.test(x)&&!qual)rank=98;
 else if(/uefa europa league/.test(x)&&!qual)rank=92;
 else if(/copa libertadores|conmebol libertadores/.test(x)&&!qual)rank=91;
 else if(/fifa club world cup|club world cup fifa/.test(x))rank=90;
 else if(/uefa conference league/.test(x)&&!qual)rank=87;
 else if(/afc champions league elite|champions league elite/.test(x)&&!qual)rank=84;
 // Strong second tiers are checked BEFORE Big-5 patterns so "La Liga 2" / "2. Bundesliga" can never inherit top-flight rank.
 else if(/england.*championship|english.*championship|efl championship/.test(x))rank=78;
 else if(/spain.*(la liga 2|laliga 2|segunda)|spanish.*(la liga 2|laliga 2|segunda)|^(la liga 2|laliga 2|segunda division)$/.test(x))rank=74;
 else if(/italy.*serie b|italian.*serie b|^serie b$/.test(x))rank=73;
 else if(/(germany|german).*2\.? ?bundesliga|2\.? ?bundesliga.*(germany|german)|^2\.? ?bundesliga$/.test(x))rank=73;
 else if(/france.*ligue 2|french.*ligue 2|^ligue 2$/.test(x))rank=71;
 // Big-5 senior domestic leagues: country identity prevents false positives.
 else if((/(england|english)/.test(x)&&/premier league/.test(x))||bare(x,'premier league','epl'))rank=97;
 else if((/(spain|spanish)/.test(x)&&/(la liga|primera division)/.test(x)&&!/(la liga 2|laliga 2|segunda)/.test(x))||bare(x,'la liga','laliga','primera division'))rank=95;
 else if((/(italy|italian)/.test(x)&&/serie a/.test(x))||bare(x,'serie a'))rank=94;
 else if((/(germany|german)/.test(x)&&/bundesliga/.test(x)&&!/2\.? ?bundesliga/.test(x))||bare(x,'bundesliga'))rank=93;
 else if((/(france|french)/.test(x)&&/ligue 1/.test(x))||bare(x,'ligue 1'))rank=91;
 else if(/brazil.*serie a|brasileir|argentina.*primera|liga profesional.*argentina/.test(x))rank=83;
 else if(/primeira liga|portugal.*primeira|eredivisie|netherlands.*eredivisie/.test(x))rank=82;
 else if(/belgian pro league|belgium.*first division|turk.*super lig|super lig.*turk|saudi pro league|major league soccer|^mls$/.test(x))rank=79;
 else if(/scottish premiership|scotland.*premiership|greek super league|greece.*super league|austria.*bundesliga|swiss super league/.test(x))rank=72;
 // Major domestic cups; later rounds may be especially notable but round metadata is not always available.
 else if(/fa cup|copa del rey|coppa italia|dfb pokal|coupe de france|efl cup|carabao/.test(x))rank=80;
 else if(/nations league/.test(x))rank=81;
 else if(/world cup qualification|euro qualification|copa america qualification/.test(x))rank=76;
 else if(/champions league|premier league|super league|first league|pro league|premier division/.test(x))rank=52;
 if(qual&&rank>=84)rank-=10;
 if(friendly)rank=Math.min(rank,50);
 if(youth)rank=Math.min(rank,38);
 if(women){
  if(/england.*(fa )?women.*super league|women.*super league.*england|^women s super league$|^wsl$/.test(x))rank=Math.max(Math.min(rank,74),72);
  else if(/women.*champions league|uefa women/.test(x))rank=Math.max(rank,78);
  else rank=Math.min(rank,66);
 }
 return rank;
}
export function nextThreeAmVN(from=Date.now()){
 const v=new Date(from+VN_OFFSET),y=v.getUTCFullYear(),m=v.getUTCMonth(),d=v.getUTCDate();
 // Yêu cầu R49: luôn tính từ thời điểm bấm tới 03:00 của NGÀY HÔM SAU (giờ VN).
 // Không rút cửa sổ còn vài giờ khi người dùng bấm trước 03:00.
 return Date.UTC(y,m,d+1,3,0,0)-VN_OFFSET;
}
export function bigMatchMeta(p){
 const rank=leagueRank(p?.league),home=teamTier(p?.home),away=teamTier(p?.away),club=home+away;
 const books=Math.min(Number(p?.ah?.books||0),Number(p?.ou?.books||0));
 const balance=(Number(p?.ah?.mainBalance??.08)+Number(p?.ou?.mainBalance??.08))/2;
 const method=(Number(p?.ah?.methodConsensus??.5)+Number(p?.ou?.methodConsensus??.5))/2;
 const strength=(Number(p?.ah?.strength||0)+Number(p?.ou?.strength||0))/2;
 const marketDepth=Math.max(0,Math.min(12,books))*1.25;
 const marketBalance=Math.max(0,1-Math.min(.12,balance)/.12)*5;
 const modelSupport=Math.max(0,Math.min(1,method))*3+Math.max(0,Math.min(1,strength))*3;
 const clubDraw=Math.min(10,club*2.2+(home>=3&&away>=3?2:0));
 let importance=rank*.72+clubDraw+marketDepth+marketBalance+modelSupport;
 // Hard ceiling: a small/youth competition cannot leapfrog a senior Big-5 fixture because of club name or book count.
 if(rank<60)importance=Math.min(importance,60);
 if(rank<45)importance=Math.min(importance,48);
 const hot=rank>=90||(rank>=78&&club>=4)||(rank>=72&&home>=3&&away>=2);
 return{leagueRank:rank,hot,importance:+importance.toFixed(3),marketDepth:+marketDepth.toFixed(2),bigTeams:club,homeTier:home,awayTier:away};
}
export function isGlobalBigMatch(p,meta=bigMatchMeta(p)){
 // Do not fill the "big matches" list with small competitions just to reach 30.
 // A senior Big-5/major continental match qualifies by competition alone. Outside that
 // tier we require recognizable clubs AND enough market depth, using bookmaker coverage
 // as a live proxy for how broadly the match is actually followed/priced that day.
 const rank=Number(meta?.leagueRank||0),clubs=Number(meta?.bigTeams||0);
 const books=Math.min(Number(p?.ah?.books||0),Number(p?.ou?.books||0));
 if(rank>=87)return true;                                  // UEFA/CONMEBOL majors + Big-5
 if(rank>=80&&clubs>=2)return true;                        // major cup / Brazil-Argentina etc.; không bắt buộc nhiều book
 if(rank>=78&&clubs>=3)return true;                        // strong secondary/global-interest leagues
 if(rank>=72&&meta?.homeTier>=3&&meta?.awayTier>=2)return true; // elite-v-elite exception; market depth chỉ để xếp hạng
 return false;
}
export function rankBigPredictions(rows,from=Date.now(),to=nextThreeAmVN(from),limit=30){
 const seen=new Set(),pool=[];
 for(const p of rows||[]){
  const t=Date.parse(p?.date);if(!Number.isFinite(t)||t<from||t>to)continue;
  const k=`${norm(p.home)}|${norm(p.away)}|${Math.round(t/60000)}`;if(seen.has(k))continue;seen.add(k);
  const meta=bigMatchMeta(p);if(!isGlobalBigMatch(p,meta))continue;
  pool.push({...p,bigMatch:meta});
 }
 // Phase 1: choose the genuinely biggest matches of the day by importance.
 pool.sort((a,b)=>b.bigMatch.importance-a.bigMatch.importance||b.bigMatch.leagueRank-a.bigMatch.leagueRank||Number(b.bigMatch.hot)-Number(a.bigMatch.hot)||b.bigMatch.bigTeams-a.bigMatch.bigTeams||b.bigMatch.marketDepth-a.bigMatch.marketDepth||Date.parse(a.date)-Date.parse(b.date));
 // Phase 2: only after the top set is fixed, present those selected big matches chronologically.
 const selected=pool.slice(0,Math.max(1,Math.min(30,limit)));
 selected.sort((a,b)=>Date.parse(a.date)-Date.parse(b.date)||b.bigMatch.importance-a.bigMatch.importance);
 return selected;
}
