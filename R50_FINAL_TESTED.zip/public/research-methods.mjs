// Shadow challengers: same locked line and odds as the original R38 methods.
// New challengers are SHADOW only until they have >=60 graded events and beat baseline in both
// halves of the sample; adding them cannot immediately flip a live pick.
export const NEW_METHODS=['power_consensus','log_pool','median_logit','winsor_consensus','book_majority','form_poisson','recent_poisson','rest_poisson','form_market_blend','xg_poisson','elo_sos','line_movement','expert_consensus'];
export function powerProbability(leftOdd,rightOdd){const a=1/leftOdd,b=1/rightOdd;if(!(a>0&&a<1&&b>0&&b<1))return .5;let lo=0,hi=32;for(let i=0;i<60;i++){const k=(lo+hi)/2;if(a**k+b**k>1)lo=k;else hi=k}return a**((lo+hi)/2)}
function median(a){if(!a.length)return .5;const z=[...a].sort((x,y)=>x-y),m=z.length>>1;return z.length%2?z[m]:(z[m-1]+z[m])/2}
function sigmoid(x){return 1/(1+Math.exp(-x))}
export function challengerProbabilities(pairs){
 const p=pairs.map(x=>{const a=1/x.lo,b=1/x.ro;return Math.max(.001,Math.min(.999,a/(a+b)))}),
 power=pairs.map(x=>powerProbability(x.lo,x.ro)),logits=p.map(x=>Math.log(x/(1-x))),sorted=[...p].sort((a,b)=>a-b),wins=sorted.length>=5?sorted.slice(1,-1):sorted,
 majority=p.length?p.filter(x=>x>=.5).length/p.length:.5;
 return {
  power_consensus:power.reduce((a,b)=>a+b,0)/power.length,
  log_pool:sigmoid(logits.reduce((a,b)=>a+b,0)/logits.length),
  median_logit:sigmoid(median(logits)),
  winsor_consensus:wins.reduce((a,b)=>a+b,0)/Math.max(1,wins.length),
  // Soften a pure majority vote toward 0.5 so one noisy book cannot create an extreme signal.
  book_majority:.5+(majority-.5)*.55
 };
}
export function netProfit(grade,odd){return Number.isFinite(odd)&&odd>1?(grade>0?grade*(odd-1):grade):null}
export function eligibleMethod(id,box){if(!NEW_METHODS.includes(id))return true;const ev=(box?.[id]?.events||[]).filter(x=>Number.isFinite(x.profit)&&Number.isFinite(x.baselineProfit)).slice(-120);if(ev.length<60)return false;const blocks=[ev.slice(0,Math.floor(ev.length/2)),ev.slice(Math.floor(ev.length/2))];return blocks.every(b=>b.reduce((s,x)=>s+x.profit-x.baselineProfit,0)/b.length>.02&&b.reduce((s,x)=>s+x.g-x.baselineGrade,0)>0)}
export function roiSummary(rec){const ev=(rec?.events||[]).filter(x=>Number.isFinite(x.profit));return {n:ev.length,roi:ev.length?100*ev.reduce((a,x)=>a+x.profit,0)/ev.length:null}}
