import assert from 'node:assert/strict';
import {leagueRank,rankBigPredictions,isGlobalBigMatch} from '../public/big-matches.mjs';
import {marketPairs,bestCluster} from '../public/market-core.mjs';

assert.equal(leagueRank('English Premier League'),97);
assert.equal(leagueRank('Spanish La Liga'),95);
assert.equal(leagueRank('Italian Serie A'),94);
assert.equal(leagueRank('German Bundesliga'),93);
assert.equal(leagueRank('French Ligue 1'),91);
assert.ok(leagueRank('Belarusian Premier League')<70);
assert.ok(leagueRank('Welsh Premier League')<70);
assert.ok(leagueRank('Estonia Champions League')<70);
assert.ok(leagueRank('England U21 Premier League')<50);
assert.equal(leagueRank('Spanish La Liga 2'),74);
assert.equal(leagueRank('German 2. Bundesliga'),73);

const t0=Date.now(),kick=new Date(t0+3600000).toISOString();
const pred=(league,home,away)=>({league,home,away,date:kick,ah:{books:4,mainBalance:.01,methodConsensus:.6,strength:.6},ou:{books:4,mainBalance:.01,methodConsensus:.6,strength:.6}});
const ranked=rankBigPredictions([
 pred('Welsh Premier League','Caernarfon','Cambrian Clydach'),
 pred('English Premier League','Brentford','Chelsea'),
 pred('German Bundesliga','Bayern Munich','Union Berlin'),
 pred('Spanish La Liga','Espanyol','Elche'),
 pred('Italian Serie A','Monza','Sassuolo'),
 pred('French Ligue 1','Monaco','Lens'),
 pred('Belarusian Premier League','ML Vitebsk','Arsenal Dzyarzhynsk'),
 pred('England U21 Premier League','Aston Villa U21','Middlesbrough U21')
],t0,t0+7200000,30);
assert.deepEqual(new Set(ranked.slice(0,5).map(x=>x.league)),new Set(['English Premier League','Spanish La Liga','Italian Serie A','German Bundesliga','French Ligue 1']));
assert.equal(ranked.some(x=>x.league==='Welsh Premier League'),false);
assert.equal(ranked.some(x=>x.league==='Belarusian Premier League'),false);
assert.equal(ranked.some(x=>x.league==='England U21 Premier League'),false);
assert.equal(ranked.length,5);
assert.equal(rankBigPredictions([pred('Spanish La Liga 2','Albacete','Cordoba')],t0,t0+7200000,30).length,0);
assert.equal(isGlobalBigMatch(pred('Spanish La Liga','Espanyol','Elche')),true);

const bookmakers=[];
for(let i=0;i<6;i++)bookmakers.push({name:'Main'+i,bets:[{name:'Asian Handicap',values:[{value:'Home -0.5',odd:1.88+i*.005},{value:'Away 0.5',odd:1.98-i*.005}]}]});
for(let i=0;i<2;i++)bookmakers.push({name:'Alt'+i,bets:[{name:'Asian Handicap',values:[{value:'Home -0.25',odd:1.92},{value:'Away 0.25',odd:1.92}]}]});
const main=bestCluster(marketPairs({od:[{bookmakers}]},'AH'));
assert.equal(main.line,-.5);
assert.equal(main.g.length,6);

console.log(JSON.stringify({pass:true,checks:['minor Premier/Champions League demoted','Big-5 ordering','strict no-filler big-match gate','U21/La Liga 2 excluded','broad-book balanced main line beats 2-book secondary line']},null,2));
