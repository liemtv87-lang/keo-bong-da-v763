import assert from 'node:assert/strict';
import fs from 'node:fs';
import worker,{AutoBrain} from '../worker.js';
import {NEW_METHODS} from '../research-methods.mjs';
import {leagueRank} from '../public/big-matches.mjs';
import {proGate,parseXgStats,rollingElo,forebetVote,movementVote,clvFor} from '../pro-analysis.mjs';
import {ledgerTotals} from '../ledger.mjs';

const workerSrc=fs.readFileSync(new URL('../worker.js',import.meta.url),'utf8');
const appSrc=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const indexSrc=fs.readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
const cfg=JSON.parse(fs.readFileSync(new URL('../wrangler.jsonc',import.meta.url),'utf8'));
assert.ok(workerSrc.includes('BG_SCAN_OFFSETS=[0,10,20,30,40,50,60].map(m=>m*60_000)'));
assert.ok(workerSrc.includes('LINE_SNAPSHOT_OFFSETS=[6*3600_000,3*3600_000,1*3600_000,15*60_000,2*60_000]'));
assert.ok(workerSrc.includes('LINE_SNAPSHOT_MIN_GAP_MS=5*60_000'));
assert.ok(workerSrc.includes("freshKeys.has(bgPredKey(d.p))"));
assert.ok(workerSrc.includes("['closing',2*60_000]"));
assert.ok(workerSrc.includes('now>=t+3*3600_000'));
assert.ok(workerSrc.includes("['ESPN',espnDayResults]"));
assert.ok(workerSrc.includes('resultSourceCount:5'));
assert.ok(appSrc.includes('/api/background/touch'));
assert.ok(appSrc.includes('actionable:true'));
assert.ok(appSrc.includes('/api/background/bootstrap-keys'));
assert.ok(indexSrc.includes('data-keyinput="K02"')&&indexSrc.includes('data-keyinput="K04"')&&indexSrc.includes('LƯU + TEST LÊN CLOUD'));
assert.ok(!workerSrc.includes('Key fingerprint không khớp bản R49'));
assert.ok(appSrc.includes('12:00→13:00'));
assert.equal(NEW_METHODS.length,13);
assert.ok(NEW_METHODS.includes('xg_poisson')&&NEW_METHODS.includes('elo_sos')&&NEW_METHODS.includes('line_movement')&&NEW_METHODS.includes('expert_consensus'));
assert.equal(leagueRank('Spanish La Liga 2'),74);
assert.equal(leagueRank('German 2. Bundesliga'),73);
assert.ok(leagueRank('Estonia Champions League')<60);
assert.ok(leagueRank('England U21 Premier League')<50);
assert.equal(cfg.name,'keobongda-pro');
assert.equal(cfg.durable_objects.bindings.length,1);
assert.equal(cfg.durable_objects.bindings[0].name,'AUTO_BRAIN');
assert.equal(cfg.durable_objects.bindings[0].script_name,undefined);
assert.ok(cfg.migrations?.[0]?.new_sqlite_classes?.includes('AutoBrain'));

const health=await (await worker.fetch(new Request('https://x/api/health'),{},{})).json();
assert.equal(health.build,'R50_PRO');
assert.equal(health.selftest.ok,true);
assert.equal(health.keySelftest.ok,true);
assert.ok(health.serverKeys.configured>=0 && health.serverKeys.configured<=2);

const xg=parseXgStats({statistics:[{period:'ALL',groups:[{statisticsItems:[{name:'Expected goals',home:'1.75',away:'0.83'}]}]}]});
assert.deepEqual(xg,{home:1.75,away:.83});
const base={home:'Alpha',away:'Beta',league:'English Premier League',date:new Date(Date.now()+3600000).toISOString(),ah:{type:'AH',pick:'Home',line:-.5,books:5,strength:.45,leftOdd:1.93,rightOdd:1.95,methodVotes:{},methodProbabilities:{}},ou:{type:'OU',pick:'Over',line:2.75,books:5,strength:.42,leftOdd:1.92,rightOdd:1.94,methodVotes:{},methodProbabilities:{}}};
const pro={dataQuality:.82,xgModel:{AH:{pick:'Home',prob:.67},OU:{pick:'Over',prob:.64}},eloVote:{pick:'Home',prob:.61},movement:{AH:{pick:'Home',prob:.59},OU:{pick:'Over',prob:.58}},expert:{AH:{pick:'Home',confidence:.58},OU:{pick:'Over',confidence:.57}},lineup:{available:true,confirmed:false,homeMissing:0,awayMissing:0}};
const gated=proGate(base,pro,{big:true});assert.equal(gated.ah.actionable,true);assert.equal(gated.ou.actionable,true);assert.ok(gated.ah.methodVotes.xg_poisson);
const weak=proGate({...base,league:'Welsh Premier League',ah:{...base.ah,books:2},ou:{...base.ou,books:2}},{dataQuality:.2},{big:false});assert.equal(weak.ah.actionable,true);assert.equal(weak.ah.noBetReason,'');assert.ok(weak.ah.proQualityNote);
const mv=movementVote('AH',{first:{line:-.25,leftOdd:1.98,rightOdd:1.86},last:{line:-.5,leftOdd:1.91,rightOdd:1.95}});assert.ok(mv&&['Home','Away'].includes(mv.pick));
const cv=clvFor('AH','Home',{first:{line:-.25,leftOdd:1.98,rightOdd:1.86},last:{line:-.5,leftOdd:1.91,rightOdd:1.95}});assert.ok(Number.isFinite(cv));
const fb=forebetVote(base,'Alpha Beta 1 2-1 55%');assert.equal(fb?.score,'2-1');

const ev=(id,hid,aid,hs,as,ts)=>({id,startTimestamp:Math.floor(ts/1000),status:{type:'finished'},homeTeam:{id:hid},awayTeam:{id:aid},homeScore:{current:hs},awayScore:{current:as}});
const before=Date.now(),events=[ev(1,1,3,2,0,before-9*86400000),ev(2,2,4,0,1,before-8*86400000),ev(3,1,4,1,1,before-4*86400000),ev(4,2,3,3,1,before-3*86400000)];
const elo=rollingElo(1,2,events.filter(e=>e.homeTeam.id===1||e.awayTeam.id===1),events.filter(e=>e.homeTeam.id===2||e.awayTeam.id===2),before);assert.ok(Number.isFinite(elo.diff));

const skipped={...base,ah:{...base.ah,actionable:false},ou:{...base.ou,actionable:true},ahGrade:1,ouGrade:-1,settledAt:Date.now()};
const totals=ledgerTotals([skipped],[]);assert.equal(totals.AH.total,0);assert.equal(totals.AH.skipped,1);assert.equal(totals.OU.total,1);

class MemStore{constructor(){this.m=new Map();this.alarm=0}async get(k){return this.m.get(k)}async put(k,v){if(typeof k==='object'&&arguments.length===1){for(const [a,b] of Object.entries(k))this.m.set(a,b)}else this.m.set(k,v)}async delete(k){for(const x of Array.isArray(k)?k:[k])this.m.delete(x)}async setAlarm(t){this.alarm=t}async transaction(fn){return fn(this)}}
const storage=new MemStore(),brain=new AutoBrain({storage},{}),state=await brain.stateView();
assert.equal(state.meta.dailyWindowEnd-state.meta.dailyWindowStart,86400000);
assert.equal(state.meta.resultSourceCount,5);
assert.equal(state.meta.scanPolicy,'12:00-13:00 VN / 10 phút/lần (7 lượt)');
assert.equal(state.meta.ordinaryNoBet,false);
assert.equal(state.meta.legacyImportStatus,'disabled-new-instance');
console.log(JSON.stringify({pass:true,checks:['fresh new Worker/DO','12:00-13:00 every 10m','line snapshots 6h/3h/1h/15m/closing + retry-safe','5 result feeds','xG/Elo/SoS hooks','expert + movement votes','main-line always publishes picks','CLV learning hook','2-key cloud shared input layer','league collision guards']},null,2));
