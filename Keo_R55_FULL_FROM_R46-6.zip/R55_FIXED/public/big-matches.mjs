const VN_OFFSET=7*3600_000;
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&amp;/g,'and').replace(/[^a-z0-9]+/g,' ').trim();
const BIG_TEAMS=[
 'real madrid','barcelona','atletico madrid','athletic bilbao','sevilla','villarreal','real sociedad',
 'manchester city','manchester united','liverpool','arsenal','chelsea','tottenham','newcastle united','aston villa',
 'bayern munich','borussia dortmund','rb leipzig','bayer leverkusen','eintracht frankfurt',
 'inter milan','internazionale','ac milan','juventus','napoli','roma','lazio','atalanta',
 'paris saint germain','psg','marseille','monaco','lyon','lille',
 'benfica','porto','sporting cp','sporting lisbon','ajax','psv','feyenoord',
 'galatasaray','fenerbahce','besiktas','olympiacos','celtic','rangers',
 'river plate','boca juniors','flamengo','palmeiras','corinthians','sao paulo','fluminense','botafogo','gremio','internacional',
 'al hilal','al nassr','al ittihad','al ahli','inter miami','la galaxy',
 'argentina','brazil','brasil','france','spain','england','germany','italy','portugal','netherlands','belgium','croatia','uruguay','colombia','japan','south korea'
].map(norm);
const MINOR_LEAGUE_RE=/(^| )(women|womens|woman|ladies|lady|femenina|femenino|feminine|feminino|feminin|femin|youth|academy|reserve|reserves|development|u17|u18|u19|u20|u21|u22|u23|amateur|friendly|friendlies|rfef|segunda federacion|tercera federacion|primera federacion|segunda division|liga 2|league one|league two|national league|serie b|serie c|2 bundesliga|3 liga|ligue 2|championship)( |$)/;
function teamLooksMinor(name){const x=norm(name);if(!x)return false;return /(^| )(u17|u18|u19|u20|u21|u22|u23|youth|academy|reserves?|women|womens|ladies)( |$)/.test(x)||/(^| )(ii|iii)$/.test(x)||/(^| )b$/.test(x)}
function isMinorFixture(p){const league=norm(p?.league),h=norm(p?.home),a=norm(p?.away),all=`${league} ${h} ${a}`;if(MINOR_LEAGUE_RE.test(all))return true;const hw=/(^| )w$/.test(h),aw=/(^| )w$/.test(a);if(hw&&aw)return true;return teamLooksMinor(h)||teamLooksMinor(a)}
function teamTier(name){const x=norm(name);if(!x||teamLooksMinor(x))return 0;for(const t of BIG_TEAMS)if(x===t||(x.length>=5&&t.length>=5&&(x.includes(t)||t.includes(x))))return 1;return 0}
export function leagueRank(name){const x=norm(name);if(!x||MINOR_LEAGUE_RE.test(x))return 0;const rules=[
 [100,/^(uefa )?champions league$|^ucl$|champions league( group| knockout| qualification)?$/],
 [99,/^fifa world cup$|^world cup$|^uefa euro( 20\d\d)?$|^euro 20\d\d$|^copa america$/],
 [98,/^club world cup$|^fifa club world cup$/],
 [96,/^premier league$|^english premier league$|^england premier league$|^epl$/],
 [94,/^la liga$|^laliga( ea sports)?$|^spain la liga$/],
 [92,/^serie a$|^italy serie a$|^italian serie a$/],
 [90,/^bundesliga$|^germany bundesliga$/],
 [88,/^ligue 1$|^france ligue 1$/],
 [86,/^uefa europa league$|^europa league$/],
 [84,/^uefa conference league$|^conference league$/],
 [83,/copa libertadores|libertadores/],
 [81,/copa sudamericana|sudamericana/],
 [80,/brasileirao serie a|brasileir[a-z ]* serie a|brazil serie a|argentina liga profesional|liga profesional argentina|argentina primera division/],
 [79,/afc champions league elite|afc champions league|champions league elite/],
 [78,/^saudi pro league$|^primeira liga$|^eredivisie$|^super lig$|^major league soccer$|^mls$/],
 [76,/^scottish premiership$|^belgian pro league$|^j1 league$/],
 [75,/^fa cup$|^copa del rey$|^coppa italia$|^dfb pokal$|^coupe de france$|^efl cup$|^carabao cup$/],
 [72,/uefa nations league|world cup qualification|world cup qualifiers|euro qualification|euro qualifiers/]
 ];for(const [s,re] of rules)if(re.test(x))return s;return 40}
export function nextThreeAmVN(from=Date.now()){
 const v=new Date(from+VN_OFFSET);const y=v.getUTCFullYear(),m=v.getUTCMonth(),d=v.getUTCDate();return Date.UTC(y,m,d+1,3,0,0)-VN_OFFSET;
}
export function bigMatchMeta(p){const rank=leagueRank(p?.league),home=teamTier(p?.home),away=teamTier(p?.away),both=home+away>=2,one=home+away>=1,books=Math.min(Number(p?.ah?.books||0),Number(p?.ou?.books||0)),balance=(Number(p?.ah?.mainBalance||.08)+Number(p?.ou?.mainBalance||.08))/2,method=(Number(p?.ah?.methodConsensus||.5)+Number(p?.ou?.methodConsensus||.5))/2,strength=(Number(p?.ah?.strength||0)+Number(p?.ou?.strength||0))/2,quality=Math.max(0,books*3+(1-Math.min(.2,balance)*5)*8+method*5+strength*4),hot=!isMinorFixture(p)&&(both||(rank>=94&&one)||(rank>=98));return{leagueRank:rank,hot,quality:+quality.toFixed(3),bigTeams:home+away}}
export function rankBigPredictions(rows,from=Date.now(),to=nextThreeAmVN(from),limit=30){
 const seen=new Set(),pool=[];for(const p of rows||[]){const t=Date.parse(p?.date);if(!Number.isFinite(t)||t<from||t>to)continue;const k=`${norm(p.home)}|${norm(p.away)}|${Math.round(t/60000)}`;if(seen.has(k))continue;seen.add(k);pool.push({...p,bigMatch:bigMatchMeta(p)})}
 // "Tối đa 30" means never pad with obscure fixtures just to reach 30.
 const eligible=pool.filter(p=>!isMinorFixture(p)&&(p.bigMatch.leagueRank>=75||p.bigMatch.bigTeams>0||(p.bigMatch.leagueRank>=72&&p.bigMatch.bigTeams>0)));
 eligible.sort((a,b)=>Number(b.bigMatch.hot)-Number(a.bigMatch.hot)||b.bigMatch.leagueRank-a.bigMatch.leagueRank||b.bigMatch.bigTeams-a.bigMatch.bigTeams||b.bigMatch.quality-a.bigMatch.quality||Date.parse(a.date)-Date.parse(b.date));
 const chosen=eligible.slice(0,Math.max(1,Math.min(30,limit)));
 return chosen.sort((a,b)=>Date.parse(a.date)-Date.parse(b.date));
}
