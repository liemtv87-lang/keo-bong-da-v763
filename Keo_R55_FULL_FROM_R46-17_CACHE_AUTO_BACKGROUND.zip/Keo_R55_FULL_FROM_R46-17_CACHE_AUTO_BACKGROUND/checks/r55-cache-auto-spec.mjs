import fs from 'node:fs';
import {MAIN_FOOTBALL_COMPETITIONS,isMainCompetition,rankBigPredictions} from '../public/big-matches.mjs';
import {RESULT_STATS_SOURCES} from '../result-sources.mjs';
const worker=fs.readFileSync(new URL('../worker.js',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const wrangler=fs.readFileSync(new URL('../wrangler.jsonc',import.meta.url),'utf8');
function fnBody(src,name,next){const a=src.indexOf(name);if(a<0)return'';const b=next?src.indexOf(next,a+name.length):-1;return src.slice(a,b>0?b:Math.min(src.length,a+10000));}
const manual=fnBody(worker,'async manualSuccess(req)','async fetch(req)');
const tick=fnBody(worker,'async tick(force=false','async stateView()');
const stateView=fnBody(worker,'async stateView()','async startManualCloudScan');
const big=fnBody(app,'async function scanBigMatches()','function ');
const twenty=fnBody(app,'async function tryUseSharedPool','async function syncCloudBackground');
const tests=[
 ['Cloudflare cron every 10 minutes exists',/"\*\/10 \* \* \* \*"/.test(wrangler)],
 ['4-hour pool interval',/BG_FETCH_MS=4\*3600_000/.test(worker)],
 ['background scan is sequential one-source batch',/BG_BATCH=1/.test(worker)&&/runBatch\(ids,base,diag,rows,'market',1\)/.test(worker)],
 ['background scan continues by alarm',/BG_SCAN_GAP_MS=5000/.test(worker)&&/setAlarm\(next\)/.test(worker)],
 ['4h schedule tied to pool scan, not manual button',/lastPoolScanSuccessAt\|\|m\.lastAutoAt/.test(tick)&&/lastPoolScanSuccessAt\|\|m\.lastAutoAt/.test(stateView)],
 ['manual success cannot stop active cache scan',!manual.includes('scanActive=false')&&!manual.includes("put('scanRows',[])" )&&!manual.includes('scanCursor=0')],
 ['non-resetting ensure-scan route exists',worker.includes("u.pathname==='/ensure-scan'")&&worker.includes("async ensureCloudScan(mode='cache-request')")],
 ['cache top-up uses non-resetting route',app.includes("api('/api/background/ensure-scan'")],
 ['20-match button reads shared cache first',twenty.includes('/api/background/state')&&twenty.includes('loadSharedPoolFromCloud')&&twenty.includes('không quét lại từ nguồn')],
 ['big-match button reads cache, not full source pass',big.includes('/api/background/state')&&big.includes('/api/background/pool')&&!big.includes('collectFullMarketPass')],
 ['10 score/result sources configured',RESULT_STATS_SOURCES.length===10&&RESULT_STATS_SOURCES.every(x=>x.score&&x.form&&x.stats)],
 ['three structured form/stat sources wired',worker.includes("sourcesTried:['SofaScore','365Scores','FotMob']")],
 ['main-football whitelist populated',MAIN_FOOTBALL_COMPETITIONS.length>=70],
 ['main top flights accepted',isMainCompetition('English Premier League')&&isMainCompetition('Brazil Serie A')&&isMainCompetition('Japan J1 League')],
 ['lower divisions rejected',!isMainCompetition('Spain Primera Federación')&&!isMainCompetition('Argentina Primera B Metropolitana')],
 ['big-match strict gate never fills from lower divisions',rankBigPredictions([{date:new Date(Date.now()+3600000).toISOString(),league:'Spain Primera Federación',home:'Real Madrid Castilla',away:'Extremadura',ah:{books:5},ou:{books:5}}]).length===0],
];
const bad=tests.filter(([,ok])=>!ok);
for(const [name,ok] of tests) console.log(`${ok?'PASS':'FAIL'}  ${name}`);
if(bad.length){console.error(`\n${bad.length}/${tests.length} FAILED`);process.exit(1)}
console.log(`\nR55 cache/background audit PASS ${tests.length}/${tests.length}`);
