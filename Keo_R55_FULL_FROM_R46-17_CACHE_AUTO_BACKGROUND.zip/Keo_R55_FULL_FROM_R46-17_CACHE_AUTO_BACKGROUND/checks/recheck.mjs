import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
const root=new URL('../',import.meta.url);
const modules={};for(const name of ['research-methods','ledger','text-codec','source-health','collection','market-core','big-matches'])Object.assign(modules,await import(new URL('public/'+name+'.mjs',root)));
class Element{constructor(id=''){this.id=id;this.disabled=false;this.textContent='';this.innerHTML='';this.value='';this.dataset={};this.children=[];this.className='';this.classList={contains:()=>false,toggle:()=>{}}}append(...x){this.children.push(...x)}prepend(...x){this.children.unshift(...x)}addEventListener(){} querySelectorAll(){return []} }
const elements=new Map(),get=id=>{if(!elements.has(id))elements.set(id,new Element(id));return elements.get(id)},storage=new Map();
let fakeFetch=async()=>{throw Error('offline')};const requests=[];
const sandbox={...modules,console,Date,Intl,Map,Set,TextDecoder,TextEncoder,Uint8Array,AbortController,Promise,performance,URL,encodeURIComponent,setTimeout,clearTimeout,setInterval:()=>0,document:{getElementById:get,querySelectorAll:()=>[],createElement:()=>new Element()},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},navigator:{clipboard:{writeText:async t=>{sandbox.copied=t}}},fetch:async(...args)=>{requests.push(args[0]);return fakeFetch(...args)},prompt:()=>{}};
vm.createContext(sandbox);
let src=fs.readFileSync(new URL('public/app.js',root),'utf8').replace(/^import .*;\n/gm,'').replace(/;load\(\);\s*$/, ';');
vm.runInContext(src,sandbox);
const run=s=>vm.runInContext(s,sandbox),now=Date.now();
const p=i=>({id:i,home:'Adelaide United '+i,away:'Tai Po FC',league:'AFC Champions League 2',date:new Date(now+3600000+i*60000).toISOString(),ah:{type:'AH',pick:'Home',line:-.5,books:3,leftOdd:1.91,rightOdd:1.95,strength:.4},ou:{type:'OU',pick:'Over',line:2.5,books:3,leftOdd:1.92,rightOdd:1.9,strength:.3}});
const rows=Array.from({length:269},(_,i)=>p(i));storage.set('fep_v783_pending',JSON.stringify(rows));sandbox.rows=rows;
run('CLOUD_AUTO={pending:rows,history:[]};state.pred=rows.slice(0,20)');
let t=performance.now();run('renderLearn()');const renderMs=performance.now()-t;assert.ok(renderMs<500,`render took ${renderMs}`);
t=performance.now();run('render()');const resultMs=performance.now()-t;
assert.match(get('results').innerHTML,/Adelaide United/);
await run('copyAll()');assert.match(sandbox.copied,/AH:/);
for(const n of [6,8,10]){run(`showAcca(${n})`);assert.match(get('acca').innerHTML,new RegExp(`COPY XIÊN ${n}`))}
run('beginScan()');assert.equal(get('scan').disabled,true);assert.equal(get('bigScan').disabled,true);assert.equal(get('stopScan').disabled,false);
fakeFetch=async(url,opt)=>new Promise((resolve,reject)=>opt.signal.addEventListener('abort',()=>reject(Error('aborted'))));
const pending=run("api('/api/market?offset=0&limit=3').catch(e=>e.message)");run('stopScan()');assert.equal(await pending,'aborted');run('endScan()');assert.equal(get('scan').disabled,false);
let caught=false;try{await run("api('/api/market?offset=0&limit=3')")}catch{caught=true}assert.ok(caught);
run('beginScan()');sandbox.itemCount=0;await run('dynamicPool([1,2,3],1,async()=>{STOP_SCAN=true;return 1},()=>{itemCount++})');assert.equal(sandbox.itemCount,1);run('endScan()');
// New selection uses exactly one bounded form call and doesn't rewrite locked records.
run('STOP_SCAN=false');requests.length=0;fakeFetch=async(url,opt)=>({ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',predictions:JSON.parse(opt.body).predictions})});sandbox.fresh=Array.from({length:30},(_,i)=>p(500+i));const enriched=await run('enrichPredictions(fresh)');assert.equal(enriched.length,30);assert.equal(requests.length,1);
requests.length=0;const locked=await run('enrichPredictions(rows.slice(0,20))');assert.equal(requests.length,0);assert.deepEqual(JSON.parse(JSON.stringify(locked)),rows.slice(0,20));
// Failed sync must not block results or throw away local predictions.
fakeFetch=async()=>{throw Error('offline')};await run('notifyCloudManualSuccess()');assert.ok(get('results').innerHTML.includes('Adelaide United'));assert.equal(JSON.parse(storage.get('fep_v783_pending')).length,269);
// Manual cloud-data check + manual settle controls.
requests.length=0;fakeFetch=async(url,opt)=>{const q=new URL(url,'https://test');if(q.pathname==='/api/background/state')return {ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',cloudBackground:true,predictions:rows.slice(0,20),featuredPredictions:rows.slice(0,5),pending:rows.slice(0,12),history:rows.slice(12,20),model:{},methodLab:{AH:{},OU:{},champion:{AH:'book_weight',OU:'book_weight'}}})};throw Error('unexpected '+url)};
await run('checkSavedData()');assert.match(get('savedStatus').textContent,/Cloud đã lưu: 20 dự đoán thường/);
requests.length=0;fakeFetch=async(url,opt)=>{const q=new URL(url,'https://test');if(q.pathname==='/api/background/settle-now')return {ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',settled:3,state:{ok:true,build:'R55',cloudBackground:true,predictions:rows.slice(0,20),featuredPredictions:rows.slice(0,5),pending:rows.slice(0,9),history:rows.slice(9,20),model:{},methodLab:{AH:{},OU:{},champion:{AH:'book_weight',OU:'book_weight'},updatedAt:Date.now()},meta:{lastLearnAt:Date.now()}}})};throw Error('unexpected '+url)};
await run('settleNow()');assert.match(get('savedStatus').textContent,/Chấm xong: thêm 3 trận/);assert.equal(JSON.parse(storage.get('fep_v783_pending')).length,9);

// Text preservation after codec optimization.
assert.equal(modules.cleanLabel('Việt Nam — Thắng nửa'),'Việt Nam — Thắng nửa');assert.equal(modules.cleanLabel('<font>Arsenal</font>'),'Arsenal');assert.equal(modules.repairText('FranÃ§ais'),'Français');

// Full scan: source data succeeds while Cloud ledger sync is unavailable.
const fixture=i=>({f:{fixture:{id:'S01_'+i,date:new Date(Date.now()+3600000+i*60000).toISOString()},league:{name:'Premier League'},teams:{home:{name:'Alpha '+i},away:{name:'Beta '+i}}},od:[{bookmakers:['Book A','Book B','Book C'].map(name=>({name,bets:[{name:'Asian Handicap',values:[{value:'Home -0.5',odd:1.91},{value:'Away 0.5',odd:1.95}]},{name:'Goals Over/Under',values:[{value:'Over 2.5',odd:1.92},{value:'Under 2.5',odd:1.9}]}]}))}]});
fakeFetch=async(url,opt)=>{if(url.includes('/manual-success')||url.includes('/sync-ledger'))throw Error('cloud offline');const q=new URL(url,'https://test');let data;if(q.pathname==='/api/market')data={ok:true,build:'R55',window:{from:Number(q.searchParams.get('ts'))},rows:Array.from({length:30},(_,i)=>fixture(i)),sourceHealth:{healthy:3,checked:3},scanComplete:true};else if(q.pathname==='/api/background/form')data={ok:true,build:'R55',predictions:JSON.parse(opt.body).predictions};else if(q.pathname==='/api/key/providers')data={ok:true,build:'R55',providers:[]};else throw Error('unexpected '+url);return {ok:true,text:async()=>JSON.stringify(data)}};
run("SOURCES_READY=true;SOURCE_ORDER=['S01','S02','S03','S04','S05','S06'];ENABLED_FAMILY_COUNT=6;state.pred=[];state.rows=[];state.keyProviders=[{id:'K02'}];STOP_SCAN=false");
await run('scanLegacyClient(true)');assert.equal(run('state.pred.length'),20);assert.equal(get('scan').disabled,false);assert.equal(run('SCAN_BUSY'),false);assert.match(get('status').textContent,/20\/20/);assert.match(get('results').innerHTML,/Alpha/);
await run('scanBigMatches()');assert.equal(run('state.bigPred.length'),30);assert.equal(get('bigScan').disabled,false);await run('copyBig()');assert.match(sandbox.copied,/Alpha/);
// Main LẤY KÈO button now starts a server-owned scan and can reconnect after tab suspension.
run('state.pred=[];state.rows=[];STOP_SCAN=false;SCAN_BUSY=false;CLOUD_SCAN_ACTIVE=false;CLOUD_SCAN_WATCHER=null');requests.length=0;
const cloudPred=Array.from({length:20},(_,i)=>p(700+i));let cloudStateCalls=0;
fakeFetch=async(url,opt={})=>{const q=new URL(url,'https://test');let data;if(q.pathname==='/api/background/state'){cloudStateCalls++;data=cloudStateCalls===1?{ok:true,build:'R55',cloudBackground:true,meta:{scanActive:false,lastSuccessAt:1},poolMeta:{rowCount:0,updatedAt:0,complete:false},predictions:[],pending:[],history:[],model:{},methodLab:{AH:{},OU:{},champion:{AH:'book_weight',OU:'book_weight'}}}:{ok:true,build:'R55',cloudBackground:true,meta:{scanActive:false,lastSuccessAt:Date.now(),scanFinishedAt:Date.now(),activeSourceCount:95},poolMeta:{rowCount:1143,updatedAt:Date.now(),complete:true,checkedSources:95,totalSources:95},predictions:cloudPred,pending:[],history:[],model:{},methodLab:{AH:{},OU:{},champion:{AH:'book_weight',OU:'book_weight'}}};}else if(q.pathname==='/api/background/start-scan')data={ok:true,build:'R55',cloudBackground:true,meta:{scanActive:true,scanCursor:0,scanRows:0,scanMode:'manual-ui',activeSourceCount:95},poolMeta:{rowCount:0,updatedAt:0,complete:false,totalSources:95}};else if(q.pathname==='/api/background/scan-status')data={ok:true,build:'R55',cloudBackground:true,meta:{scanActive:false,scanCursor:95,scanRows:1143,scanFinishedAt:Date.now(),lastSuccessAt:Date.now(),activeSourceCount:95},poolMeta:{rowCount:1143,updatedAt:Date.now(),complete:true,checkedSources:95,totalSources:95},predictions:cloudPred};else if(q.pathname==='/api/background/pool')data={ok:true,build:'R55',rows:[],poolMeta:{rowCount:1143,updatedAt:Date.now(),complete:true,checkedSources:95,totalSources:95}};else if(q.pathname==='/api/background/sync-ledger')data={ok:true,build:'R55',acknowledged:[]};else throw Error('unexpected '+url);return {ok:true,text:async()=>JSON.stringify(data)}};
await run('scan()');assert.equal(run('state.pred.length'),20);assert.equal(run('SCAN_BUSY'),false);assert.equal(run('CLOUD_SCAN_ACTIVE'),false);assert.match(get('status').textContent,/Quét cloud xong/);assert.ok(requests.some(x=>String(x).includes('/api/background/start-scan')));assert.ok(requests.some(x=>String(x).includes('/api/background/scan-status')));
let poolError=false;try{await run('dynamicPool([1],1,async()=>1,()=>{throw Error("render broke")})')}catch{poolError=true}assert.ok(poolError);

// An acknowledged upload must never be posted again in the same session.
await new Promise(r=>setTimeout(r,20));
run('CLOUD_AUTO={pending:[],history:[]};LEDGER_ACK.clear()');storage.set('fep_v783_pending',JSON.stringify([p(900)]));
let uploads=0;fakeFetch=async(url,opt)=>{uploads++;return {ok:true,text:async()=>JSON.stringify({ok:true,acknowledged:JSON.parse(opt.body).predictions.map(modules.ledgerKey)})}};
await run('uploadPendingLedger()');await run('uploadPendingLedger()');assert.equal(uploads,1,'ACK should prevent duplicate upload');

// Stop during Find must not start a second scan.
run("state.rows=[];state.pred=[];state.scanComplete=false;state.scanFinishedAt=0;STOP_SCAN=false");get('team').value='missing team';let scans=0;const originalScan=run('scan');sandbox.scan=async(...args)=>{scans++;return originalScan(...args)};
fakeFetch=async(url,opt)=>{if(url.startsWith('/api/market')){run('stopScan()');throw Error('stopped')}throw Error('offline')};
await run('findTeam()');assert.equal(scans,1);assert.equal(get('find').disabled,false);assert.match(get('teamStatus').textContent,/Đã dừng/);sandbox.scan=originalScan;
// A separate TEST KEY still works after Stop.
fakeFetch=async()=>({ok:true,text:async()=>JSON.stringify({ok:true})});await run("api('/api/key/check',{method:'POST'})");
// Full search does not stop after its first 20 matches.
run("STOP_SCAN=false;SOURCE_ORDER=Array.from({length:12},(_,i)=>'S'+String(i+1).padStart(2,'0'));ENABLED_FAMILY_COUNT=12;state.rows=[];state.pred=[]");let marketCalls=0;
fakeFetch=async(url,opt)=>{const q=new URL(url,'https://test');if(q.pathname==='/api/market'){marketCalls++;return {ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',window:{from:Number(q.searchParams.get('ts'))},rows:Array.from({length:30},(_,i)=>fixture(i)),sourceHealth:{healthy:3,checked:3},scanComplete:true})}}if(q.pathname==='/api/background/form')return {ok:true,text:async()=>JSON.stringify({ok:true,predictions:JSON.parse(opt.body).predictions})};throw Error('offline')};
await run('scan(true)');assert.equal(marketCalls,12);assert.equal(run('state.scanComplete'),true);
// Cloud sync cannot replace in-progress results, including a request already in flight.
await new Promise(r=>setTimeout(r,20));let releaseState;fakeFetch=async()=>new Promise(resolve=>{releaseState=()=>resolve({ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',cloudBackground:true,predictions:[p(999)],pending:[],history:[]})})});
const before=run('JSON.stringify(state.pred)');const sync=run('syncCloudBackground()');run('BIG_BUSY=true');releaseState();await sync;assert.equal(run('JSON.stringify(state.pred)'),before);run('BIG_BUSY=false');
// Pool failure waits for its other active task and suppresses late callbacks.
let slowDone=false,lateCallback=false;sandbox.slow=async()=>{await new Promise(r=>setTimeout(r,15));slowDone=true};sandbox.late=()=>{lateCallback=true};
await assert.rejects(run('dynamicPool([1,2],2,async i=>{if(i===2)await slow();return i},pack=>{if(pack.value===1)throw Error("bad render");late()})'));
assert.ok(slowDone);assert.equal(lateCallback,false);

// Old saved fixtures do not reset a successful-fetch timer when all sources return empty.
await new Promise(r=>setTimeout(r,20));storage.delete('fep_v783_reserve');sandbox.old18=rows.slice(0,18);run('state.pred=old18;state.rows=[];STOP_SCAN=false');let successPosts=0;
fakeFetch=async(url,opt)=>{const q=new URL(url,'https://test');if(q.pathname==='/api/background/manual-success')successPosts++;if(q.pathname==='/api/market')return {ok:true,text:async()=>JSON.stringify({ok:true,build:'R55',window:{from:Number(q.searchParams.get('ts'))},rows:[],sourceHealth:{empty:3,checked:3},scanComplete:true})};throw Error('offline')};
await run('scan(true)');assert.equal(successPosts,0);assert.equal(run('state.pred.length'),18);assert.match(get('status').textContent,/dữ liệu đã lưu/);
console.log('Additional regression checks: ACK dedupe, Stop during Find, TEST KEY after Stop, full scan coverage, cloud sync race, pool drain: PASS');
console.log(JSON.stringify({pass:true,tests:['render 269-record ledger','render predictions','copy predictions','acca 6/8/10','scan exclusivity','stop abort','stop prevents new requests','pool stop','single form call for 30','locked predictions unchanged','offline sync retains results','Vietnamese/HTML/mojibake','scan returns 20 with cloud offline','big scan returns 30 with cloud offline','copy big','pool callback failure unlocks'],renderMs:Math.round(renderMs),resultMs:Math.round(resultMs)},null,2));
